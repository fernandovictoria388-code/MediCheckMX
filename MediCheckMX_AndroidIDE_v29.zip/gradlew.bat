@echo off
where gradle >nul 2>nul
if errorlevel 1 (
  echo ERROR: Gradle not found in PATH.
  exit /b 127
)
gradle %*
