package mx.medicheck.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.InputStream;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.SharedPreferences;
import org.json.JSONObject;
import org.json.JSONException;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import android.util.Base64;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.vision.Frame;
import com.google.android.gms.vision.text.TextBlock;
import com.google.android.gms.vision.text.TextRecognizer;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanner;
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import android.util.SparseArray;

public class MainActivity extends Activity {
    private static final int REQUEST_PHOTO = 1001;
    private Uri photoUri;

    private TextView info, codeValue, codeFormat, analysisTitle, analysisResult;
    private TextView fieldName, fieldActive, fieldConcentration, fieldPresentation;
    private TextView fieldManufacturer, fieldRegistry, fieldLot, fieldExpiry, consistency;
    private ImageView packagePhoto;
    private Button btnSearchInfo, btnPhoto, btnScanAgain, btnAnalyze, btnCofepris;
    private Button btnCofeprisRegistry, btnCofeprisName, btnCofeprisActive, btnCofeprisManufacturer;
    private Button btnVerifyAutomatic, btnServerConfig, btnSyncCofepris, btnGemini;
    private SharedPreferences prefs;
    private TextView cofeprisStatus;
    private TextRecognizer textRecognizer;
    private String scannedCode = "";
    private String scannedFormat = "";
    private Bitmap packageBitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button scan = findViewById(R.id.btnScan);
        Button search = findViewById(R.id.btnSearch);
        Button pharmacies = findViewById(R.id.btnPharmacies);
        Button alerts = findViewById(R.id.btnAlerts);
        info = findViewById(R.id.txtInfo);
        codeValue = findViewById(R.id.txtCodeValue);
        codeFormat = findViewById(R.id.txtCodeFormat);
        packagePhoto = findViewById(R.id.imgPackage);
        btnSearchInfo = findViewById(R.id.btnSearchInfo);
        btnPhoto = findViewById(R.id.btnPhoto);
        btnScanAgain = findViewById(R.id.btnScanAgain);
        btnAnalyze = findViewById(R.id.btnAnalyze);
        btnCofepris = findViewById(R.id.btnCofepris);
        btnCofeprisRegistry = findViewById(R.id.btnCofeprisRegistry);
        btnCofeprisName = findViewById(R.id.btnCofeprisName);
        btnCofeprisActive = findViewById(R.id.btnCofeprisActive);
        btnCofeprisManufacturer = findViewById(R.id.btnCofeprisManufacturer);
        cofeprisStatus = findViewById(R.id.txtCofeprisStatus);
        btnVerifyAutomatic = findViewById(R.id.btnVerifyAutomatic);
        btnServerConfig = findViewById(R.id.btnServerConfig);
        btnSyncCofepris = findViewById(R.id.btnSyncCofepris);
        btnGemini = findViewById(R.id.btnGemini);
        prefs = getSharedPreferences("medicheck", MODE_PRIVATE);
        analysisTitle = findViewById(R.id.txtAnalysisTitle);
        analysisResult = findViewById(R.id.txtAnalysisResult);
        fieldName = findViewById(R.id.txtFieldName);
        fieldActive = findViewById(R.id.txtFieldActive);
        fieldConcentration = findViewById(R.id.txtFieldConcentration);
        fieldPresentation = findViewById(R.id.txtFieldPresentation);
        fieldManufacturer = findViewById(R.id.txtFieldManufacturer);
        fieldRegistry = findViewById(R.id.txtFieldRegistry);
        fieldLot = findViewById(R.id.txtFieldLot);
        fieldExpiry = findViewById(R.id.txtFieldExpiry);
        consistency = findViewById(R.id.txtConsistency);

        textRecognizer = new TextRecognizer.Builder(getApplicationContext()).build();

        scan.setOnClickListener(v -> startMedicineScanner());
        search.setOnClickListener(v -> { if (scannedCode.isEmpty()) startMedicineScanner(); else showLookupMessage(); });
        pharmacies.setOnClickListener(v -> Toast.makeText(this, "Farmacias se añadirán en la siguiente etapa", Toast.LENGTH_SHORT).show());
        alerts.setOnClickListener(v -> Toast.makeText(this, "Alertas COFEPRIS se añadirán en la siguiente etapa", Toast.LENGTH_SHORT).show());
        btnSearchInfo.setOnClickListener(v -> showLookupMessage());
        btnPhoto.setOnClickListener(v -> takePackagePhoto());
        btnScanAgain.setOnClickListener(v -> startMedicineScanner());
        btnAnalyze.setOnClickListener(v -> analyzePackagePhoto());
        btnCofepris.setOnClickListener(v -> showCofeprisSearchOptions());
        btnCofeprisRegistry.setOnClickListener(v -> openCofeprisWithCriterion("Registro sanitario", getFieldValue(fieldRegistry)));
        btnCofeprisName.setOnClickListener(v -> openCofeprisWithCriterion("Denominación distintiva", getFieldValue(fieldName)));
        btnCofeprisActive.setOnClickListener(v -> openCofeprisWithCriterion("Principio activo", getFieldValue(fieldActive)));
        btnCofeprisManufacturer.setOnClickListener(v -> openCofeprisWithCriterion("Fabricante", getFieldValue(fieldManufacturer)));
        btnVerifyAutomatic.setOnClickListener(v -> verifyAutomatically());
        btnServerConfig.setOnClickListener(v -> configureServer());
        btnSyncCofepris.setOnClickListener(v -> syncCofepris());
        btnGemini.setOnClickListener(v -> analyzeWithGemini());
        setIdentificationVisible(false);
    }

    private void startMedicineScanner() {
        GmsBarcodeScannerOptions options = new GmsBarcodeScannerOptions.Builder()
                .setBarcodeFormats(Barcode.FORMAT_EAN_13, Barcode.FORMAT_EAN_8, Barcode.FORMAT_UPC_A,
                        Barcode.FORMAT_UPC_E, Barcode.FORMAT_CODE_128, Barcode.FORMAT_DATA_MATRIX,
                        Barcode.FORMAT_QR_CODE).build();
        GmsBarcodeScanner scanner = GmsBarcodeScanning.getClient(this, options);
        scanner.startScan().addOnSuccessListener(new OnSuccessListener<Barcode>() {
            @Override public void onSuccess(Barcode barcode) {
                scannedCode = barcode.getRawValue();
                if (scannedCode == null || scannedCode.trim().isEmpty()) scannedCode = "Código detectado sin contenido legible";
                scannedFormat = formatName(barcode.getFormat());
                showIdentificationScreen();
                Toast.makeText(MainActivity.this, "Código detectado", Toast.LENGTH_SHORT).show();
            }
        }).addOnCanceledListener(() -> Toast.makeText(this, "Escaneo cancelado", Toast.LENGTH_SHORT).show())
          .addOnFailureListener(e -> Toast.makeText(this, "No se pudo iniciar el escáner: " + e.getMessage(), Toast.LENGTH_LONG).show());
    }

    private void showIdentificationScreen() {
        codeValue.setText(scannedCode);
        codeFormat.setText("Formato: " + scannedFormat);
        info.setText("Código capturado. Fotografía el envase para identificar sus datos.");
        setIdentificationVisible(true);
    }

    private void showLookupMessage() {
        info.setText("Consulta COFEPRIS preparada. Se prioriza el registro sanitario y después se cruzan nombre, principio activo y fabricante.\n\nCódigo: " + scannedCode + "\n\nLa fuente oficial se abrirá para la consulta pública.");
    }

    private void showCofeprisSearchOptions() {
        final String registry = getFieldValue(fieldRegistry);
        final String name = getFieldValue(fieldName);
        final String active = getFieldValue(fieldActive);
        final String manufacturer = getFieldValue(fieldManufacturer);

        StringBuilder summary = new StringBuilder();
        summary.append("Consulta priorizada\n\n");
        if (!isUnknown(registry)) summary.append("1. Registro sanitario: ").append(registry).append("\n");
        if (!isUnknown(name)) summary.append("2. Denominación distintiva: ").append(name).append("\n");
        if (!isUnknown(active)) summary.append("3. Principio activo: ").append(active).append("\n");
        if (!isUnknown(manufacturer)) summary.append("4. Fabricante: ").append(manufacturer).append("\n");
        summary.append("\nCOFEPRIS permite consultar por número de registro, denominación distintiva/genérica, principio activo, fabricante y otros criterios.");

        String[] options = {
                "Copiar criterio principal",
                "Abrir visor oficial COFEPRIS",
                "Copiar todos los datos"
        };
        new AlertDialog.Builder(this)
                .setTitle("Consulta COFEPRIS precisa")
                .setMessage(summary.toString())
                .setItems(options, (dialog, which) -> {
                    if (which == 0) {
                        String value = !isUnknown(registry) ? registry : (!isUnknown(name) ? name : (!isUnknown(active) ? active : scannedCode));
                        copyToClipboard("Criterio COFEPRIS", value);
                        Toast.makeText(this, "Criterio copiado: " + value, Toast.LENGTH_SHORT).show();
                    } else if (which == 1) {
                        openCofepris();
                    } else {
                        String all = buildCofeprisQuery();
                        copyToClipboard("Datos MediCheck MX", all);
                        Toast.makeText(this, "Datos de consulta copiados", Toast.LENGTH_SHORT).show();
                        openCofepris();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private String getFieldValue(TextView field) {
        if (field == null) return "No identificado";
        String s = field.getText() == null ? "" : field.getText().toString();
        int p = s.indexOf(":");
        if (p >= 0) s = s.substring(p + 1).trim();
        return s.trim().isEmpty() ? "No identificado" : s.trim();
    }

    private String buildCofeprisQuery() {
        StringBuilder q = new StringBuilder();
        String registry = getFieldValue(fieldRegistry);
        String name = getFieldValue(fieldName);
        String active = getFieldValue(fieldActive);
        String concentration = getFieldValue(fieldConcentration);
        String presentation = getFieldValue(fieldPresentation);
        String manufacturer = getFieldValue(fieldManufacturer);
        if (!isUnknown(registry)) q.append("Registro sanitario: ").append(registry).append("\n");
        if (!isUnknown(name)) q.append("Denominación distintiva: ").append(name).append("\n");
        if (!isUnknown(active)) q.append("Principio activo: ").append(active).append("\n");
        if (!isUnknown(concentration)) q.append("Concentración: ").append(concentration).append("\n");
        if (!isUnknown(presentation)) q.append("Presentación: ").append(presentation).append("\n");
        if (!isUnknown(manufacturer)) q.append("Fabricante: ").append(manufacturer).append("\n");
        q.append("Código de barras: ").append(scannedCode == null ? "" : scannedCode);
        return q.toString();
    }

    private void copyToClipboard(String label, String value) {
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText(label, value == null ? "" : value));
    }

    private void openCofeprisWithCriterion(String label, String value) {
        if (isUnknown(value)) {
            Toast.makeText(this, label + " no fue identificado", Toast.LENGTH_SHORT).show();
            return;
        }
        copyToClipboard("Criterio COFEPRIS", value);
        cofeprisStatus.setVisibility(View.VISIBLE);
        cofeprisStatus.setText("Criterio preparado: " + label + "\n\"" + value + "\"\n\nEl visor oficial se abrirá. Pega este criterio en el campo correspondiente y verifica el resultado.");
        openCofepris();
    }

    private void openCofepris() {
        String url = "https://registros.cofepris.gob.mx/";
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        try {
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo abrir el visor oficial de COFEPRIS", Toast.LENGTH_LONG).show();
        }
    }

    private String getServerUrl() {
        return prefs == null ? "" : prefs.getString("server_url", "").trim();
    }

    private void configureServer() {
        final android.widget.EditText input = new android.widget.EditText(this);
        input.setSingleLine(true);
        input.setHint("https://tu-servidor/verify");
        input.setText(getServerUrl());
        new AlertDialog.Builder(this)
                .setTitle("Servidor de verificación")
                .setMessage("v24 usa un backend para consultar una base normalizada de registros COFEPRIS. No se incluye una URL falsa ni una base simulada.")
                .setView(input)
                .setPositiveButton("Guardar", (d, w) -> {
                    String url = input.getText().toString().trim();
                    prefs.edit().putString("server_url", url).apply();
                    cofeprisStatus.setVisibility(View.VISIBLE);
                    cofeprisStatus.setText(url.isEmpty() ? "Servidor eliminado. Se usará la consulta oficial manual." : "Servidor guardado: " + url);
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void syncCofepris() {
        final String server = getServerUrl();
        if (server.isEmpty()) {
            cofeprisStatus.setVisibility(View.VISIBLE);
            cofeprisStatus.setText("🟡 Configura primero el servidor de MediCheck MX.");
            return;
        }
        final String endpoint = (server.endsWith("/") ? server : server + "/") + "sync";
        btnSyncCofepris.setEnabled(false);
        cofeprisStatus.setVisibility(View.VISIBLE);
        cofeprisStatus.setText("Sincronizando datos públicos de COFEPRIS...\n\nEl servidor descargará los documentos publicados por COFEPRIS.");
        new Thread(() -> {
            String response = null; String error = null; HttpURLConnection conn = null;
            try {
                URL url = new URL(endpoint);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST"); conn.setConnectTimeout(15000); conn.setReadTimeout(60000);
                conn.setDoOutput(true); conn.setRequestProperty("Content-Length", "0");
                int code = conn.getResponseCode();
                InputStreamReader reader = new InputStreamReader(code >= 400 ? conn.getErrorStream() : conn.getInputStream(), StandardCharsets.UTF_8);
                BufferedReader br = new BufferedReader(reader); StringBuilder sb = new StringBuilder(); String line;
                while ((line = br.readLine()) != null) sb.append(line); br.close(); response = sb.toString();
                if (code >= 400) error = "HTTP " + code + ": " + response;
            } catch (Exception e) { error = e.getClass().getSimpleName() + ": " + e.getMessage(); }
            finally { if (conn != null) conn.disconnect(); }
            final String r = response, e = error;
            runOnUiThread(() -> {
                btnSyncCofepris.setEnabled(true);
                if (e != null) { cofeprisStatus.setText("🟡 No se pudo sincronizar COFEPRIS.\n\n" + e); return; }
                try {
                    JSONObject o = new JSONObject(r == null ? "{}" : r);
                    cofeprisStatus.setText("🟢 Sincronización COFEPRIS completada\n\nRegistros cargados: " + o.optInt("record_count", 0) + "\nEstados revocados/cancelados: " + o.optInt("status_count", 0) + "\n\nFuente: " + o.optString("sources", "Documentos públicos COFEPRIS"));
                } catch (Exception ex) { cofeprisStatus.setText("🟡 Respuesta de sincronización no reconocida:\n\n" + r); }
            });
        }).start();
    }

    private void verifyAutomatically() {
        final String server = getServerUrl();
        if (server.isEmpty()) {
            cofeprisStatus.setVisibility(View.VISIBLE);
            cofeprisStatus.setText("🟡 Verificación automática no configurada.\n\nConfigura el servidor de MediCheck para consultar los datos regulatorios. Mientras tanto, usa el visor oficial COFEPRIS.");
            new AlertDialog.Builder(this)
                    .setTitle("Configurar verificación automática")
                    .setMessage("El v25 conecta el cliente con un backend que puede sincronizar los documentos públicos de COFEPRIS.")
                    .setPositiveButton("Configurar servidor", (d,w) -> configureServer())
                    .setNegativeButton("Abrir COFEPRIS", (d,w) -> openCofepris())
                    .show();
            return;
        }

        String endpoint = server.endsWith("/") ? server : server + "/";
        endpoint += "verify";
        final String endpointFinal = endpoint;
        final String payload = buildVerificationJson();
        btnVerifyAutomatic.setEnabled(false);
        cofeprisStatus.setVisibility(View.VISIBLE);
        cofeprisStatus.setText("Consultando servidor de verificación...\nNo cierres la aplicación.");

        new Thread(() -> {
            String response = null;
            String error = null;
            HttpURLConnection conn = null;
            try {
                URL url = new URL(endpointFinal);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(20000);
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                byte[] body = payload.getBytes(StandardCharsets.UTF_8);
                conn.setFixedLengthStreamingMode(body.length);
                OutputStream out = conn.getOutputStream();
                out.write(body); out.flush(); out.close();
                int code = conn.getResponseCode();
                InputStreamReader reader = new InputStreamReader(code >= 400 ? conn.getErrorStream() : conn.getInputStream(), StandardCharsets.UTF_8);
                BufferedReader br = new BufferedReader(reader);
                StringBuilder sb = new StringBuilder(); String line;
                while ((line = br.readLine()) != null) sb.append(line);
                br.close();
                response = sb.toString();
                if (code >= 400) error = "HTTP " + code + ": " + response;
            } catch (Exception e) { error = e.getClass().getSimpleName() + ": " + e.getMessage(); }
            finally { if (conn != null) conn.disconnect(); }

            final String finalResponse = response;
            final String finalError = error;
            runOnUiThread(() -> {
                btnVerifyAutomatic.setEnabled(true);
                if (finalError != null) {
                    cofeprisStatus.setText("🟡 No se pudo completar la verificación automática.\n\n" + finalError + "\n\nPuedes abrir el visor oficial COFEPRIS para comprobar manualmente.");
                    return;
                }
                renderVerificationResponse(finalResponse);
            });
        }).start();
    }

    private String buildVerificationJson() {
        JSONObject o = new JSONObject();
        try {
            o.put("barcode", scannedCode == null ? "" : scannedCode);
            o.put("name", getFieldValue(fieldName));
            o.put("active_ingredient", getFieldValue(fieldActive));
            o.put("concentration", getFieldValue(fieldConcentration));
            o.put("presentation", getFieldValue(fieldPresentation));
            o.put("manufacturer", getFieldValue(fieldManufacturer));
            o.put("registry", getFieldValue(fieldRegistry));
            o.put("lot", getFieldValue(fieldLot));
            o.put("expiry", getFieldValue(fieldExpiry));
        } catch (JSONException ignored) {}
        return o.toString();
    }

    private void renderVerificationResponse(String response) {
        if (response == null || response.trim().isEmpty()) {
            cofeprisStatus.setText("🟡 El servidor respondió vacío.");
            return;
        }
        try {
            JSONObject o = new JSONObject(response);
            String status = o.optString("status", "REVIEW");
            int confidence = o.optInt("confidence", 0);
            String title;
            if ("MATCH".equalsIgnoreCase(status)) title = "🟢 REGISTRO COINCIDENTE";
            else if ("REVOKED".equalsIgnoreCase(status)) title = "🔴 REGISTRO REVOCADO";
            else if ("CANCELLED".equalsIgnoreCase(status)) title = "🔴 REGISTRO CANCELADO";
            else if ("NO_MATCH".equalsIgnoreCase(status)) title = "🔴 SIN COINCIDENCIA SUFICIENTE";
            else title = "🟡 REVISIÓN NECESARIA";

            StringBuilder b = new StringBuilder();
            b.append(title).append("\n");
            b.append("Confianza de coincidencia: ").append(confidence).append("/100\n\n");
            b.append(o.optString("message", "Resultado devuelto por el servidor.")).append("\n\n");
            JSONObject checks = o.optJSONObject("field_checks");
            if (checks != null) {
                b.append("Campos comparados:\n");
                java.util.Iterator<String> it = checks.keys();
                while (it.hasNext()) {
                    String k = it.next();
                    b.append(checks.optBoolean(k) ? "✅ " : "⚠️ ").append(k).append("\n");
                }
                b.append("\n");
            }
            b.append("La coincidencia de registro NO demuestra por sí sola la autenticidad física del envase.");
            cofeprisStatus.setText(b.toString());
        } catch (Exception e) {
            cofeprisStatus.setText("🟡 Respuesta no reconocida del servidor:\n\n" + response);
        }
    }

    private void takePackagePhoto() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(getPackageManager()) == null) {
            Toast.makeText(this, "No hay una aplicación de cámara disponible", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            File dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
            if (dir != null && !dir.exists()) dir.mkdirs();
            File photo = File.createTempFile("medicheck_", ".jpg", dir);
            photoUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", photo);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
            intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(intent, REQUEST_PHOTO);
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo preparar la fotografía: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_PHOTO && resultCode == RESULT_OK) {
            Bitmap bitmap = null;
            // FileProvider devuelve una content:// Uri; no se puede leer correctamente con Uri.getPath().
            // Abrimos la fotografía mediante ContentResolver para que funcione en AndroidIDE/Android 10.
            if (photoUri != null) {
                InputStream input = null;
                try {
                    input = getContentResolver().openInputStream(photoUri);
                    if (input != null) bitmap = BitmapFactory.decodeStream(input);
                } catch (Exception ignored) {
                    bitmap = null;
                } finally {
                    if (input != null) {
                        try { input.close(); } catch (Exception ignored) {}
                    }
                }
            }
            if (bitmap == null && data != null && data.getExtras() != null && data.getExtras().get("data") instanceof Bitmap) {
                bitmap = (Bitmap) data.getExtras().get("data");
            }
            if (bitmap != null) {
                packageBitmap = bitmap;
                packagePhoto.setImageBitmap(bitmap);
                packagePhoto.setVisibility(View.VISIBLE);
                btnAnalyze.setVisibility(View.VISIBLE);
                btnGemini.setVisibility(View.VISIBLE);
                analysisTitle.setVisibility(View.GONE);
                analysisResult.setVisibility(View.GONE);
                hideStructuredFields();
                info.setText("Fotografía capturada. Iniciando verificación automática…");
                verifyPhotoAutomatically();
            } else {
                Toast.makeText(this, "No se pudo cargar la fotografía", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void verifyPhotoAutomatically() {
        if (packageBitmap == null) return;
        final String server = getServerUrl();
        if (server.isEmpty()) {
            new AlertDialog.Builder(this)
                    .setTitle("Configurar servidor")
                    .setMessage("La verificación automática necesita un backend accesible desde el teléfono. La API key de Gemini permanece en el servidor.")
                    .setPositiveButton("Configurar", (d,w) -> configureServer())
                    .setNegativeButton("Cancelar", null).show();
            return;
        }
        btnPhoto.setEnabled(false);
        btnGemini.setVisibility(View.GONE);
        btnAnalyze.setVisibility(View.GONE);
        analysisTitle.setVisibility(View.VISIBLE);
        analysisResult.setVisibility(View.VISIBLE);
        analysisResult.setText("1/3 🤖 Gemini analiza la fotografía…\n2/3 🏥 consultando COFEPRIS…\n3/3 🔎 comparando campos…");
        new Thread(() -> {
            String response=null, error=null; HttpURLConnection conn=null;
            try {
                ByteArrayOutputStream baos=new ByteArrayOutputStream();
                packageBitmap.compress(Bitmap.CompressFormat.JPEG,82,baos);
                JSONObject payload=new JSONObject();
                payload.put("image_base64",Base64.encodeToString(baos.toByteArray(),Base64.NO_WRAP));
                payload.put("mime_type","image/jpeg");
                payload.put("barcode",scannedCode==null?"":scannedCode);
                payload.put("ocr_text",analysisResult.getText()==null?"":analysisResult.getText().toString());
                String endpoint=(server.endsWith("/")?server:server+"/")+"analyze-and-verify";
                URL url=new URL(endpoint); conn=(HttpURLConnection)url.openConnection();
                conn.setRequestMethod("POST"); conn.setConnectTimeout(15000); conn.setReadTimeout(90000); conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type","application/json; charset=UTF-8");
                byte[] body=payload.toString().getBytes(StandardCharsets.UTF_8); conn.setFixedLengthStreamingMode(body.length);
                OutputStream out=conn.getOutputStream(); out.write(body); out.flush(); out.close();
                int code=conn.getResponseCode(); InputStream stream=code>=400?conn.getErrorStream():conn.getInputStream();
                BufferedReader br=new BufferedReader(new InputStreamReader(stream,StandardCharsets.UTF_8)); StringBuilder sb=new StringBuilder(); String line;
                while((line=br.readLine())!=null) sb.append(line); br.close(); response=sb.toString();
                if(code>=400) error="HTTP "+code+": "+response;
            } catch(Exception ex){error=ex.getClass().getSimpleName()+": "+ex.getMessage();}
            finally{if(conn!=null)conn.disconnect();}
            final String r=response,e=error;
            runOnUiThread(() -> {
                btnPhoto.setEnabled(true);
                if(e!=null){analysisResult.setText("🟡 No se pudo completar la verificación automática.\n\n"+e);return;}
                renderCombinedVerification(r);
            });
        }).start();
    }

    private void renderCombinedVerification(String response) {
        try {
            JSONObject root=new JSONObject(response==null?"{}":response);
            JSONObject g=root.optJSONObject("gemini");
            if(g!=null){
                setField(fieldName,"Nombre comercial",g.optString("commercial_name","No identificado"));
                setField(fieldActive,"Principio activo",g.optString("active_ingredient","No identificado"));
                setField(fieldConcentration,"Concentración",g.optString("concentration","No identificado"));
                setField(fieldPresentation,"Presentación",g.optString("presentation","No identificado"));
                setField(fieldManufacturer,"Fabricante",g.optString("manufacturer","No identificado"));
                setField(fieldRegistry,"Registro sanitario",g.optString("health_registration","No identificado"));
                setField(fieldLot,"Lote",g.optString("lot","No identificado"));
                setField(fieldExpiry,"Caducidad",g.optString("expiry","No identificado"));
                showStructuredFields();
            }
            JSONObject v=root.optJSONObject("verification");
            if(v==null){analysisResult.setText("🟡 No se recibió el resultado regulatorio.\n\n"+root.optString("message","Respuesta incompleta."));return;}
            renderVerificationResponse(v.toString());
            String status=v.optString("status","REVIEW");
            analysisResult.setText("🤖 Gemini → extracción completada\n🏥 COFEPRIS → consulta completada\n🔎 Comparación → "+status+"\n\n"+v.optString("message",""));
        }catch(Exception e){analysisResult.setText("🟡 Respuesta no reconocida:\n\n"+response);}
    }

    private void analyzeWithGemini() {
        if (packageBitmap == null) {
            Toast.makeText(this, "Primero toma una fotografía del medicamento", Toast.LENGTH_SHORT).show();
            return;
        }
        final String server = getServerUrl();
        if (server.isEmpty()) {
            new AlertDialog.Builder(this)
                    .setTitle("Servidor de Gemini")
                    .setMessage("Configura el backend de MediCheck MX. La API key de Gemini debe permanecer en el servidor y nunca dentro de esta aplicación.")
                    .setPositiveButton("Configurar", (d,w) -> configureServer())
                    .setNegativeButton("Cancelar", null).show();
            return;
        }
        btnGemini.setEnabled(false);
        analysisTitle.setVisibility(View.VISIBLE);
        analysisResult.setVisibility(View.VISIBLE);
        analysisResult.setText("🤖 Gemini está analizando la fotografía del envase...\n\nNo cierres la aplicación.");
        new Thread(() -> {
            String response = null; String error = null; HttpURLConnection conn = null;
            try {
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                packageBitmap.compress(Bitmap.CompressFormat.JPEG, 82, baos);
                String imageB64 = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP);
                JSONObject payload = new JSONObject();
                payload.put("image_base64", imageB64);
                payload.put("mime_type", "image/jpeg");
                payload.put("barcode", scannedCode == null ? "" : scannedCode);
                payload.put("ocr_text", analysisResult.getText() == null ? "" : analysisResult.getText().toString());
                String endpoint = (server.endsWith("/") ? server : server + "/") + "gemini/analyze";
                URL url = new URL(endpoint);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST"); conn.setConnectTimeout(15000); conn.setReadTimeout(60000); conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                byte[] body = payload.toString().getBytes(StandardCharsets.UTF_8);
                conn.setFixedLengthStreamingMode(body.length);
                OutputStream out = conn.getOutputStream(); out.write(body); out.flush(); out.close();
                int code = conn.getResponseCode();
                InputStream stream = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
                BufferedReader br = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
                StringBuilder sb = new StringBuilder(); String line;
                while ((line = br.readLine()) != null) sb.append(line); br.close(); response = sb.toString();
                if (code >= 400) error = "HTTP " + code + ": " + response;
            } catch (Exception ex) { error = ex.getClass().getSimpleName() + ": " + ex.getMessage(); }
            finally { if (conn != null) conn.disconnect(); }
            final String r = response, e = error;
            runOnUiThread(() -> {
                btnGemini.setEnabled(true);
                if (e != null) { analysisResult.setText("🟡 Gemini no pudo analizar la fotografía.\n\n" + e); return; }
                renderGeminiResponse(r);
            });
        }).start();
    }

    private void renderGeminiResponse(String response) {
        try {
            JSONObject o = new JSONObject(response == null ? "{}" : response);
            JSONObject data = o.optJSONObject("analysis");
            if (data == null) data = o;
            setField(fieldName, "Nombre comercial", data.optString("commercial_name", "No identificado"));
            setField(fieldActive, "Principio activo", data.optString("active_ingredient", "No identificado"));
            setField(fieldConcentration, "Concentración", data.optString("concentration", "No identificado"));
            setField(fieldPresentation, "Presentación", data.optString("presentation", "No identificado"));
            setField(fieldManufacturer, "Fabricante", data.optString("manufacturer", "No identificado"));
            setField(fieldRegistry, "Registro sanitario", data.optString("health_registration", "No identificado"));
            setField(fieldLot, "Lote", data.optString("lot", "No identificado"));
            setField(fieldExpiry, "Caducidad", data.optString("expiry", "No identificado"));
            showStructuredFields();
            StringBuilder b = new StringBuilder("🤖 ANÁLISIS GEMINI COMPLETADO\n\n");
            b.append("Calidad de lectura: ").append(data.optString("image_quality", "no determinada")).append("\n");
            b.append("Inconsistencias visuales: ").append(data.optString("visual_inconsistencies", "ninguna identificada")).append("\n\n");
            b.append("Gemini organiza y analiza la fotografía; no determina por sí solo la autenticidad ni sustituye la verificación regulatoria de COFEPRIS.");
            analysisResult.setText(b.toString());
            info.setText("Gemini identificó datos del envase. Ahora puedes ejecutar la verificación automática COFEPRIS.");
        } catch (Exception e) { analysisResult.setText("🟡 Respuesta de Gemini no reconocida:\n\n" + response); }
    }

    private void analyzePackagePhoto() {
        Bitmap bitmap = packageBitmap;
        if (bitmap == null) { Toast.makeText(this, "Primero toma una fotografía", Toast.LENGTH_SHORT).show(); return; }
        Bitmap copy = bitmap.copy(Bitmap.Config.ARGB_8888, false);
        analysisTitle.setVisibility(View.VISIBLE);
        analysisResult.setVisibility(View.VISIBLE);
        analysisResult.setText("Analizando texto del envase...");
        btnAnalyze.setEnabled(false);

        if (!textRecognizer.isOperational()) {
            analysisResult.setText("El motor OCR no está disponible todavía. Conéctate a Internet y vuelve a intentar.");
            btnAnalyze.setEnabled(true); return;
        }
        try {
            Frame frame = new Frame.Builder().setBitmap(copy).build();
            SparseArray<TextBlock> items = textRecognizer.detect(frame);
            StringBuilder text = new StringBuilder();
            for (int i = 0; i < items.size(); i++) {
                TextBlock item = items.valueAt(i);
                if (item != null && item.getValue() != null && !item.getValue().trim().isEmpty()) {
                    if (text.length() > 0) text.append("\n");
                    text.append(item.getValue().trim());
                }
            }
            if (text.length() == 0) {
                analysisResult.setText("No se detectó texto legible. Toma una foto más cercana, iluminada y enfocada.");
            } else {
                populateFields(text.toString());
                analysisResult.setText("Texto detectado:\n" + text.toString() + "\n\nCampos extraídos automáticamente. Verifícalos con fuentes oficiales.");
            }
            info.setText("Identificación preliminar completada. Aún no es una verificación COFEPRIS ni prueba de autenticidad.");
        } catch (Exception e) {
            analysisResult.setText("No fue posible analizar la fotografía: " + e.getMessage());
        } finally { btnAnalyze.setEnabled(true); }
    }

    private void populateFields(String raw) {
        String normalized = raw.replace('\r', '\n')
                .replaceAll("[\\t ]+", " ")
                .replaceAll("\\n{2,}", "\\n")
                .trim();
        String[] lines = normalized.split("\\n+");

        String name = findCommercialName(lines);
        String active = findAfterLabel(normalized, "principio activo", "sustancia activa", "active ingredient", "ingrediente activo", "composición", "composicion");
        if (isUnknown(active)) active = findActiveFromContext(lines);

        String concentration = findBestConcentration(normalized);
        String presentation = findBestPresentation(normalized);
        String manufacturer = findAfterLabel(normalized, "fabricante", "laboratorio", "titular", "elaborado por", "hecho por", "manufactured by");
        String registry = findBestRegistry(normalized);
        String lot = findBestLot(normalized);
        String expiry = findBestExpiry(normalized);

        setField(fieldName, "Nombre comercial", cleanValue(cleanLabel(name)));
        setField(fieldActive, "Principio activo", cleanValue(active));
        setField(fieldConcentration, "Concentración", cleanValue(concentration));
        setField(fieldPresentation, "Presentación", cleanValue(presentation));
        setField(fieldManufacturer, "Fabricante", cleanValue(manufacturer));
        setField(fieldRegistry, "Registro sanitario", cleanValue(registry));
        setField(fieldLot, "Lote", cleanValue(lot));
        setField(fieldExpiry, "Caducidad", cleanValue(expiry));

        int identified = 0;
        if (!isUnknown(name)) identified++;
        if (!isUnknown(active)) identified++;
        if (!isUnknown(concentration)) identified++;
        if (!isUnknown(presentation)) identified++;
        if (!isUnknown(manufacturer)) identified++;
        if (!isUnknown(registry)) identified++;
        if (!isUnknown(lot)) identified++;
        if (!isUnknown(expiry)) identified++;

        String codeDigits = scannedCode == null ? "" : scannedCode.replaceAll("\\D", "");
        String textDigits = normalized.replaceAll("\\D", "");
        boolean codeFoundInText = codeDigits.length() >= 8 && textDigits.contains(codeDigits);

        if (codeFoundInText) {
            consistency.setText("🟢 Coincidencia preliminar: el código escaneado también aparece en el texto reconocido.");
        } else if (codeDigits.length() < 8) {
            consistency.setText("🟡 Revisión necesaria: el código no tiene suficientes dígitos para compararlo.");
        } else {
            consistency.setText("🟡 Revisión necesaria: el código no apareció en el texto OCR. Esto NO significa que el medicamento sea irregular.");
        }
        consistency.setVisibility(View.VISIBLE);

        StringBuilder query = new StringBuilder();
        if (!isUnknown(registry)) query.append("Registro sanitario: ").append(registry).append("\n");
        if (!isUnknown(name)) query.append("Denominación distintiva: ").append(name).append("\n");
        if (!isUnknown(active)) query.append("Principio activo: ").append(active).append("\n");
        if (!isUnknown(manufacturer)) query.append("Fabricante: ").append(manufacturer).append("\n");
        query.append("Código de barras: ").append(scannedCode);
        String confidence;
        if (!isUnknown(registry)) confidence = "Registro sanitario detectado: es el criterio principal para verificar.";
        else if (!isUnknown(name) && !isUnknown(active) && !isUnknown(manufacturer)) confidence = "Tres criterios principales detectados: nombre + principio activo + fabricante.";
        else if (!isUnknown(name) || !isUnknown(active)) confidence = "Información parcial: conviene revisar el registro directamente en COFEPRIS.";
        else confidence = "Información insuficiente para una consulta precisa.";
        cofeprisStatus.setVisibility(View.VISIBLE);
        cofeprisStatus.setText(confidence + "\n\n🟡 Resultado pendiente de confirmación oficial.");
        info.setText("Identificados " + identified + " de 8 campos.\n\nCriterios para COFEPRIS:\n" + query.toString() + "\n\nLa aplicación no marca un registro como válido hasta contrastarlo con el visor oficial de COFEPRIS.");
    }

    private String findCommercialName(String[] lines) {
        String best = "No identificado";
        int bestScore = -999;
        for (int i = 0; i < lines.length; i++) {
            String s = normalizeLine(lines[i]);
            if (s.length() < 3 || s.length() > 70) continue;
            int score = 0;
            if (s.matches(".*[A-Za-zÁÉÍÓÚáéíóúÑñ].*")) score += 2;
            if (s.matches(".*[A-Za-zÁÉÍÓÚáéíóúÑñ].*[A-Za-zÁÉÍÓÚáéíóúÑñ].*")) score += 1;
            if (s.matches("(?i).*(mg|mcg|µg|ug|g|ml|mL|%|UI|U|tabletas?|capsulas?|cápsulas?|comprimidos?|solución|suspensión|jarabe|crema|gel|gotas|ampolletas?).*")) score -= 5;
            if (s.matches("(?i).*(lote|lot|caducidad|exp|vencimiento|registro|sanitario|fabricante|laboratorio|titular|via|dosis|ingrediente|principio activo).*")) score -= 7;
            if (s.matches(".*\\d{5,}.*")) score -= 4;
            if (s.equals(s.toUpperCase(Locale.US)) && s.matches(".*[A-ZÁÉÍÓÚÑ].*")) score += 2;
            if (i == 0) score += 2;
            if (score > bestScore) { bestScore = score; best = s; }
        }
        return bestScore >= 1 ? best : "No identificado";
    }

    private String findActiveFromContext(String[] lines) {
        for (int i = 0; i < lines.length; i++) {
            String s = normalizeLine(lines[i]);
            String lower = s.toLowerCase(Locale.US);
            if (lower.contains("cada tableta") || lower.contains("cada cápsula") || lower.contains("cada capsula") || lower.contains("cada 5 ml") || lower.contains("cada ml")) {
                String before = s.replaceFirst("(?i)^.*?(?:contiene|contiene:|cada(?:\\s+tableta|\\s+cápsula|\\s+capsula|\\s+5\\s*ml|\\s+ml)).*?", "").trim();
                if (before.length() >= 3 && before.length() <= 100) return before;
            }
            if (s.matches("(?i).*(\\bmg\\b|\\bmcg\\b|µg|\\bmg/ml\\b|\\bg/ml\\b).*")) {
                String candidate = s.replaceAll("(?i)\\b\\d+(?:[.,]\\d+)?\\s*(?:mg|g|mcg|µg|ug|ml|mL|%)\\b", "").trim();
                candidate = candidate.replaceAll("(?i)^(contiene|cada tableta|cada cápsula|cada capsula)[:\\s-]*", "").trim();
                if (candidate.length() >= 3 && candidate.matches(".*[A-Za-zÁÉÍÓÚáéíóúÑñ].*")) return candidate;
            }
        }
        return "No identificado";
    }

    private String findBestConcentration(String text) {
        Matcher m = Pattern.compile("(?i)\\b\\d+(?:[.,]\\d+)?\\s*(?:mg\\s*/\\s*ml|mg\\s*/\\s*g|g\\s*/\\s*ml|mg|g|mcg|µg|ug|ml|mL|%)\\b(?:\\s*\\/\\s*(?:ml|mL|g|dosis))?").matcher(text);
        String best = "No identificado";
        while (m.find()) {
            String v = m.group().trim();
            if (best.equals("No identificado") || v.toLowerCase(Locale.US).contains("/")) best = v;
        }
        return best;
    }

    private String findBestPresentation(String text) {
        Matcher m = Pattern.compile("(?i)\\b(?:caja|frasco|blister|envase|tabletas?|capsulas?|cápsulas?|comprimidos?|ampolletas?|ampollas?|sobres?|piezas?|solución|suspensión|jarabe|crema|ungüento|unguento|gel|gotas|parches?)\\b[^\\n]{0,55}").matcher(text);
        String best = "No identificado";
        while (m.find()) {
            String v = m.group().trim();
            if (!v.matches("(?i)^(solución|suspensión|jarabe|crema|gel|gotas)$") && (best.equals("No identificado") || v.length() > best.length())) best = v;
        }
        Matcher qty = Pattern.compile("(?i)\\b\\d+\\s*(?:tabletas?|capsulas?|cápsulas?|comprimidos?|sobres?|ampolletas?|piezas?|ml)\\b").matcher(text);
        if (qty.find() && best.equals("No identificado")) best = qty.group().trim();
        return best;
    }

    private String findBestRegistry(String text) {
        Matcher m = Pattern.compile("(?i)(?:registro\\s*sanitario|reg\\.?\\s*sanitario|r\\.?s\\.?)[\\s:#-]*([A-Z0-9./-]{4,50})").matcher(text);
        if (m.find()) return m.group(1).trim();
        m = Pattern.compile("(?i)\\b(?:SSA|COFEPRIS)[\\s:#-]*[A-Z0-9./-]{4,50}\\b").matcher(text);
        return m.find() ? m.group().trim() : "No identificado";
    }

    private String findBestLot(String text) {
        Matcher m = Pattern.compile("(?i)(?:lote|lot|l:)\\s*[:#-]?\\s*([A-Z0-9./-]{2,30})").matcher(text);
        return m.find() ? m.group(1).trim() : "No identificado";
    }

    private String findBestExpiry(String text) {
        Matcher m = Pattern.compile("(?i)(?:cad(?:ucidad)?|exp(?:ira|iry)?|venc(?:imiento)?)\\s*[:#-]?\\s*((?:0?[1-9]|1[0-2])[/.-](?:20)?\\d{2}|(?:20)\\d{2}[/.-](?:0?[1-9]|1[0-2]))").matcher(text);
        if (m.find()) return m.group(1).trim();
        m = Pattern.compile("\\b((?:0?[1-9]|1[0-2])[/.-](?:20)?\\d{2}|(?:20)\\d{2}[/.-](?:0?[1-9]|1[0-2]))\\b").matcher(text);
        return m.find() ? m.group(1).trim() : "No identificado";
    }

    private String normalizeLine(String s) {
        if (s == null) return "";
        return s.replaceAll("\\s+", " ").replaceAll("^[\\s:;,.|-]+|[\\s:;,.|-]+$", "").trim();
    }

    private boolean isUnknown(String s) { return s == null || s.trim().isEmpty() || s.equalsIgnoreCase("No identificado"); }

    private String findLikelyName(String[] lines) {
        for (String line : lines) {
            String s = line.trim();
            if (s.length() >= 4 && s.length() <= 45 &&
                !s.matches("(?i).*(mg|mcg|µg|ug|ml|%|tabletas?|capsulas?|cápsulas?|lote|caducidad|registro|sanitario|fabricante|laboratorio).*")) {
                return s;
            }
        }
        return "No identificado";
    }

    private String findLikelyActive(String[] lines) {
        for (String line : lines) {
            String s = line.trim();
            if (s.length() >= 4 && s.length() <= 60 &&
                s.matches(".*[A-Za-zÁÉÍÓÚáéíóúÑñ].*") &&
                !s.matches("(?i).*(mg|mcg|µg|ug|ml|%|tabletas?|capsulas?|cápsulas?|lote|caducidad|registro|fabricante|laboratorio).*")) {
                return s;
            }
        }
        return "No identificado";
    }

    private String firstLine(String text) {
        String[] lines = text.split("\\n+");
        for (String line : lines) {
            String s = line.trim();
            if (s.length() >= 3 && !s.matches("(?i)^(lote|caducidad|exp|fabricante|laboratorio|registro sanitario).*$")) return s;
        }
        return "No identificado";
    }

    private String findAfterLabel(String text, String... labels) {
        String[] lines = text.split("\\n+");
        for (String line : lines) {
            String lower = line.toLowerCase(Locale.US);
            for (String label : labels) {
                int p = lower.indexOf(label.toLowerCase(Locale.US));
                if (p >= 0) {
                    String value = line.substring(p + label.length()).replaceAll("^[\\s:#-]+", "").trim();
                    if (!value.isEmpty()) return value;
                }
            }
        }
        return "No identificado";
    }

    private String findPattern(String text, String regex) {
        Matcher m = Pattern.compile(regex).matcher(text);
        return m.find() ? m.group().trim() : "No identificado";
    }

    private String cleanLabel(String s) { return s == null ? "No identificado" : s.replaceAll("(?i)^(nombre comercial|medicamento)[:#-]?\\s*", "").trim(); }
    private String cleanValue(String s) { return (s == null || s.trim().isEmpty()) ? "No identificado" : s.trim(); }

    private void setField(TextView view, String label, String value) { view.setText(label + ":\n" + value); view.setVisibility(View.VISIBLE); }
    private void showStructuredFields() {
        fieldName.setVisibility(View.VISIBLE); fieldActive.setVisibility(View.VISIBLE); fieldConcentration.setVisibility(View.VISIBLE);
        fieldPresentation.setVisibility(View.VISIBLE); fieldManufacturer.setVisibility(View.VISIBLE); fieldRegistry.setVisibility(View.VISIBLE);
        fieldLot.setVisibility(View.VISIBLE); fieldExpiry.setVisibility(View.VISIBLE); consistency.setVisibility(View.VISIBLE);
    }

    private void hideStructuredFields() {
        fieldName.setVisibility(View.GONE); fieldActive.setVisibility(View.GONE); fieldConcentration.setVisibility(View.GONE);
        fieldPresentation.setVisibility(View.GONE); fieldManufacturer.setVisibility(View.GONE); fieldRegistry.setVisibility(View.GONE);
        fieldLot.setVisibility(View.GONE); fieldExpiry.setVisibility(View.GONE); consistency.setVisibility(View.GONE);
    }

    private void setIdentificationVisible(boolean visible) {
        int state = visible ? View.VISIBLE : View.GONE;
        codeValue.setVisibility(state); codeFormat.setVisibility(state); btnSearchInfo.setVisibility(state); btnCofepris.setVisibility(state);
        btnPhoto.setVisibility(state); btnScanAgain.setVisibility(state);
        if (!visible) { btnAnalyze.setVisibility(View.GONE); btnGemini.setVisibility(View.GONE); analysisTitle.setVisibility(View.GONE); analysisResult.setVisibility(View.GONE); packagePhoto.setVisibility(View.GONE); hideStructuredFields(); }
    }

    private String formatName(int format) {
        switch (format) {
            case Barcode.FORMAT_EAN_13: return "EAN-13";
            case Barcode.FORMAT_EAN_8: return "EAN-8";
            case Barcode.FORMAT_UPC_A: return "UPC-A";
            case Barcode.FORMAT_UPC_E: return "UPC-E";
            case Barcode.FORMAT_CODE_128: return "Code 128";
            case Barcode.FORMAT_DATA_MATRIX: return "Data Matrix";
            case Barcode.FORMAT_QR_CODE: return "QR";
            default: return "Otro";
        }
    }
}
