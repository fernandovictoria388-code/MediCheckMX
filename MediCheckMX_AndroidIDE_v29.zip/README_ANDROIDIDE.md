# MediCheck MX v28

## Flujo principal
1. Escanear código (opcional).
2. Pulsar **📷 Verificar medicamento (foto → Gemini → COFEPRIS)**.
3. La cámara toma la foto.
4. Android envía la imagen al backend HTTPS.
5. Gemini extrae campos estructurados.
6. Backend compara contra SQLite alimentada por fuentes públicas oficiales de COFEPRIS.
7. Revocados/cancelados tienen prioridad y nunca se muestran como coincidencia vigente.
8. La app muestra 🟢 COINCIDENTE, 🟡 REVISIÓN o 🔴 NO COINCIDE.

## Importante
- La APK NO contiene la API key de Gemini.
- La APK NO contiene una base COFEPRIS inventada.
- El backend debe estar publicado en Internet con HTTPS.
- No uses `localhost` como URL del backend desde el teléfono.

## Backend
Consulta `backend/DEPLOY.md`.
